# PwmOut example

This example shows how to use PwmOut to modulate LED blinking.

**Note**: Set the cycle time. Then set the duty cycle using either a relative time period with the `write()` function or an absolute time period using the `pulsewidth()` function.


MIRRORED FROM MASTER EXAMPLE SNIPPETS REPOSITORY: mbed-os-examples-docs_only.
ANY CHANGES MADE DIRECTLY TO THIS REPOSITORY WILL BE AUTOMATICALLY OVERWRITTEN.
