/*
 * Copyright (c) 2014-2020 Arm Limited and affiliates.
 * SPDX-License-Identifier: Apache-2.0
 */

#include "mbed.h"

// Adjust pin name to your board specification.
// You can use LED1/LED2/LED3/LED4 if any is connected to PWM capable pin,
// or use any PWM capable pin, and see generated signal on logical analyzer.
PwmOut clk(PA_2);
//PwmOut enable(PA_7);
PwmOut signal(PA_15);

int main()
{

    int message[5] = {1, 2, 3, 4, 5};
    int message_length = 5;

    clk.period(0.1f);
    //enable.period(0.1f * (message_length+2));
    signal.period(0.1f);
    
    clk.write(0.1f);
    //enable.pulsewidth(0.01f);

    while(true)
    {
        signal.write(1.0f);
        ThisThread::sleep_for(99);
        signal.write(0.0f);
        ThisThread::sleep_for(99);

        for(int i=0; i<message_length; i++)
        {
            signal.write(0.1f * message[i]);
            ThisThread::sleep_for(99);
        }
        
    }


}
